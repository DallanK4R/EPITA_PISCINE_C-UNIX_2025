echo "nathan.theret" >  AUTHORS
chmod 640 AUTHORS
